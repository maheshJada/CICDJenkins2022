﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Working_Of_Innominds_People_Crud_Operation.Models
{
    public class ApplicationContext:DbContext
    {
        public ApplicationContext(DbContextOptions<ApplicationContext> options) : base(options)
        {

        }
        public DbSet<Employee> EmployeeTable { get; set; }
        public DbSet<It> ItTable { get; set; }
        public DbSet<Courier_To_The_Company> CourierTable { get; set; }
        public DbSet<Visitors> VisitorsTable { get; set; }
        public DbSet<Cafetaria> CafetariaTable { get; set; }
        public DbSet<SecuritySystemMaintanace> MaintanacesTable { get; set; }
    }
}
