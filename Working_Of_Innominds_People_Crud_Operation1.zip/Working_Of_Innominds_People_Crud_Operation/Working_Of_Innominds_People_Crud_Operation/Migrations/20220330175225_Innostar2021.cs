﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Working_Of_Innominds_People_Crud_Operation.Migrations
{
    public partial class Innostar2021 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "EmpId",
                table: "CafetariaTable");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "EmpId",
                table: "CafetariaTable",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
