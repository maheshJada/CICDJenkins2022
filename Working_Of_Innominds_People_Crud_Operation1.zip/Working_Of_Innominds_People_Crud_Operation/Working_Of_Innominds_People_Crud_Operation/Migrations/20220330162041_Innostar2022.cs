﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Working_Of_Innominds_People_Crud_Operation.Migrations
{
    public partial class Innostar2022 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Bulbs",
                table: "MaintanacesTable");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "Bulbs",
                table: "MaintanacesTable",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
