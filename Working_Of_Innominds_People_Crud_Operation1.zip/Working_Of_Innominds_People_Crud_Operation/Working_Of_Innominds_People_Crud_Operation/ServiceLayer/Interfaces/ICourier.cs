﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Working_Of_Innominds_People_Crud_Operation.Models;
namespace Working_Of_Innominds_People_Crud_Operation.ServiceLayer.Interfaces
{
    public interface ICourier
    {
        IEnumerable<Courier_To_The_Company> GetAllCourierEmployeesData();
        IEnumerable<Courier_To_The_Company> InsertTheCourierDetailsToTheRecord(Courier_To_The_Company courier);
        Courier_To_The_Company GetParticularEmployeeCourierData(int Id);
        IEnumerable<Courier_To_The_Company> UpdateTheEmployeeData(Courier_To_The_Company courier );
    }
}
