﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Working_Of_Innominds_People_Crud_Operation.Models;

namespace Working_Of_Innominds_People_Crud_Operation.ServiceLayer.Interfaces
{
    public interface IEmployee
    {
        IEnumerable<Employee> GetAllEmployee();
        IEnumerable<Employee> InsertEmployee(Employee employee);
        Employee GetById(int Id);
        IEnumerable<Employee> UpdateData(Employee category);
        bool Delete(int EmpId);
    }
}
