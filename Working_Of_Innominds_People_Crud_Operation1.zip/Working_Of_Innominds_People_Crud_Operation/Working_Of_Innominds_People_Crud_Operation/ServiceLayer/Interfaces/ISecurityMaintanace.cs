﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Working_Of_Innominds_People_Crud_Operation.Models;

namespace Working_Of_Innominds_People_Crud_Operation.ServiceLayer.Interfaces
{
    public interface ISecurityMaintanace
    {
        IEnumerable<SecuritySystemMaintanace> GetAllMaintanceData();
        IEnumerable<SecuritySystemMaintanace> InsertTheThings(SecuritySystemMaintanace maintanace);
        SecuritySystemMaintanace GetByParticularThing(int Id);
        IEnumerable<SecuritySystemMaintanace> UpdateTheThings(SecuritySystemMaintanace maintanace);
        bool DeleteTheThings(int id);
    }
}
