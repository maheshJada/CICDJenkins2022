﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Working_Of_Innominds_People_Crud_Operation.Models;
using Working_Of_Innominds_People_Crud_Operation.ServiceLayer.Interfaces;

namespace Working_Of_Innominds_People_Crud_Operation.ServiceLayer
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class CourierRepo: ICourier
    {
        private readonly ApplicationContext _applicationContext;
        public CourierRepo(ApplicationContext applicationContext)
        {
            _applicationContext = applicationContext;
        }

        [HttpGet]
        public IEnumerable<Courier_To_The_Company> GetAllCourierEmployeesData()
        {
            return _applicationContext.CourierTable;
        }
        [HttpGet]
        public Courier_To_The_Company GetParticularEmployeeCourierData(int Id)
        {
            return _applicationContext.CourierTable.Find(Id);
        }
        [HttpPost]
        public IEnumerable<Courier_To_The_Company> InsertTheCourierDetailsToTheRecord(Courier_To_The_Company courier)
        {
            _applicationContext.CourierTable.Add(courier);
            _applicationContext.SaveChanges();
            return _applicationContext.CourierTable;
        }
        [HttpPut]
        public IEnumerable<Courier_To_The_Company> UpdateTheEmployeeData(Courier_To_The_Company courier)
        {
            _applicationContext.Update(courier);
            _applicationContext.SaveChanges();
            return GetAllCourierEmployeesData();
        }
    }
}
