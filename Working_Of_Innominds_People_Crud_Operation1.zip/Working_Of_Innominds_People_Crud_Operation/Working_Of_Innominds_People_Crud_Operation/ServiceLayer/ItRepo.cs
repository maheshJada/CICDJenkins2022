﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Working_Of_Innominds_People_Crud_Operation.Models;
using Working_Of_Innominds_People_Crud_Operation.ServiceLayer.Interfaces;

namespace Working_Of_Innominds_People_Crud_Operation.ServiceLayer
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ItRepo:InIT
    {
        private readonly ApplicationContext _applicationContext;
        public ItRepo(ApplicationContext applicationContext)
        {
            _applicationContext = applicationContext;
        }
        [HttpDelete]
        public bool Delete(int it)
        {

            var emp = _applicationContext.EmployeeTable.Find(it);
            if (emp == null)
                return false;
            _applicationContext.Remove(emp);
            _applicationContext.SaveChanges();
            return true;
        }
        [HttpGet]
        public IEnumerable<It> GetEmployeeLaptopData()
        {
            return _applicationContext.ItTable;
        }
        [HttpGet]
        public It GetByLEmployeeLaptopDataById(int Id)
        {
            return _applicationContext.ItTable.Find(Id);
        }
        [HttpPost]
        public IEnumerable<It> CreateOrGiveTheLaptop(It employee)
        {
            _applicationContext.ItTable.Add(employee);
            _applicationContext.SaveChanges();
            return _applicationContext.ItTable;
        }
        [HttpPut]
        public IEnumerable<It> UpdateOrChangeTheEmployeeLaptop(It it)
        {
            _applicationContext.Update(it);
            _applicationContext.SaveChanges();
            return GetEmployeeLaptopData();
        }
    }
}
