﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Working_Of_Innominds_People_Crud_Operation.Models;
using Working_Of_Innominds_People_Crud_Operation.ServiceLayer.Interfaces;

namespace Working_Of_Innominds_People_Crud_Operation.ServiceLayer
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class EmployeeRepo:IEmployee
    {
        private readonly ApplicationContext _applicationContext;
        public EmployeeRepo(ApplicationContext applicationContext)
        {
            _applicationContext = applicationContext;
        }
        [HttpDelete]
        public bool Delete(int EmpId)
        {

            var emp = _applicationContext.EmployeeTable.Find(EmpId);
            if (emp == null)
                return false;
            _applicationContext.Remove(emp);
            _applicationContext.SaveChanges();
            return true;
        }
        [HttpGet]
        public IEnumerable<Employee> GetAllEmployee()
        {
            return _applicationContext.EmployeeTable;
        }
        [HttpGet]
        public Employee GetById(int Id)
        {
            return _applicationContext.EmployeeTable.Find(Id);
        }
        [HttpPost]
        public IEnumerable<Employee> InsertEmployee(Employee employee)
        {
            _applicationContext.EmployeeTable.Add(employee);
            _applicationContext.SaveChanges();
            return _applicationContext.EmployeeTable;
        }
        [HttpPut]
        public IEnumerable<Employee> UpdateData(Employee category)
        {
            _applicationContext.EmployeeTable.Update(category);
            _applicationContext.SaveChanges();
            return GetAllEmployee();
        }
    }
}
