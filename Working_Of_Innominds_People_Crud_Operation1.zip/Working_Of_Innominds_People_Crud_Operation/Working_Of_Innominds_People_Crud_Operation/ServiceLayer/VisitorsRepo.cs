﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Working_Of_Innominds_People_Crud_Operation.Models;
using Working_Of_Innominds_People_Crud_Operation.ServiceLayer.Interfaces;

namespace Working_Of_Innominds_People_Crud_Operation.ServiceLayer
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class VisitorsRepo:IVisitor
    {
        private readonly ApplicationContext _applicationContext;
        public VisitorsRepo(ApplicationContext applicationContext)
        {
            _applicationContext = applicationContext;
        }
        [HttpGet]
        public IEnumerable<Visitors> GetAllVistedPeeples()
        {
            return _applicationContext.VisitorsTable;
        }
        [HttpGet]

        public Visitors GetVistorsDataByID(int Id)
        {
            return _applicationContext.VisitorsTable.Find(Id);
        }
        [HttpPost]
        public IEnumerable<Visitors> InsertVistedPeoples(Visitors visitors)
        {
            _applicationContext.VisitorsTable.Add(visitors);
            _applicationContext.SaveChanges();
            return _applicationContext.VisitorsTable;
        }
    }
}
