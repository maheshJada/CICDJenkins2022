﻿using SutaAPI.Models1;
using SutaWebAPI.Common1;
using SutaWebAPI.Common1.Exceptions;
using SutaWebAPI.Repository1;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;



namespace StudentWebAPI.Repository1
{
    //Here i wrote the Query for the Student Operations
    public class SutaService : ISutaService
    {
        private SqlConnection _connection;
        private SqlCommand _command;

        public SutaService()
        {
            _connection = new SqlConnection(ApplicationContext.ConnectionString);
        }

        public bool DeleteStudent(int TokenNo)
        {
            bool delete = false;
            try
            {
                using (_command = new SqlCommand("delete from suta  where TokenNo='" + TokenNo + "'", _connection))
                {
                    if (_connection.State == System.Data.ConnectionState.Closed)
                        _connection.Open();

                    _command.ExecuteNonQuery();

                    delete = true;
                }
            }
            catch (Exception e)
            {
                throw new SutaException(e.Message);
            }
            finally
            {
                _connection.Close();
            }
            return delete;
        }

        public bool InsertStudent(string Name, int type)
        {
            bool insert = false;
            try
            {
                using (_command= new SqlCommand("insert into suta values (" + type + ",'" + Name + "')", _connection))
                {
                    if (_connection.State == System.Data.ConnectionState.Closed)
                        _connection.Open();

                    _command.ExecuteNonQuery();

                    insert = true;
                }
            }
            catch (Exception e)
            {
                throw new SutaException(e.Message);
            }
            finally
            {
                _connection.Close();
            }
            return insert;
        }

        public bool UpdateStudentToNextClass(int TokenNo)
        {
            bool update = false;
            try
            {
                using (_command = new SqlCommand("update suta set type= type+1 where TokenNo='" + TokenNo + "'", _connection))
                {
                    if (_connection.State == System.Data.ConnectionState.Closed)
                        _connection.Open();

                    _command.ExecuteNonQuery();

                    update = true;
                }
            }
            catch (Exception e)
            {
                throw new SutaException(e.Message);
            }
            finally
            {
                _connection.Close();
            }
            return update;
        }

        public IEnumerable<Suta> GetStudents()
        {
            List<Suta> _students = new List<Suta>();

            try
            {
                using (_command = new SqlCommand("SELECT * FROM Users", _connection))
                {
                    if (_connection.State == System.Data.ConnectionState.Closed)
                        _connection.Open();

                    SqlDataReader reader = _command.ExecuteReader();

                    while (reader?.Read() ?? false)
                        _students.Add(new Suta() { Name = reader.GetString(0) ,Email=reader.GetString(1),PhoneNumber=reader.GetInt32(2),Gender=reader.GetString(3),Password=reader.GetString(4)});
                }
            }
            catch (Exception e)
            {
                throw new SutaException(e.Message);
            }
            finally
            {
                if (_connection.State == System.Data.ConnectionState.Open)
                    _connection.Close();
            }

            return _students;
        }
    }
}
