﻿
using SutaAPI.Models1;
using System;
using System.Collections.Generic;

namespace SutaWebAPI.Repository1
{
    public interface ISutaService
    {
        IEnumerable<Suta> GetStudents();
        bool UpdateStudentToNextClass(int TokenNo);
        bool InsertStudent(string Name,int type);
        bool DeleteStudent(int TokenNo);
       
    }
}
