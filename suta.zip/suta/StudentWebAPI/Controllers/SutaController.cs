﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SutaWebAPI.Repository1;
using SutaAPI.Models1;

namespace SutaWebAPI1.Controllers
{
    public class SutaController : ControllerBase
    {
        private readonly ISutaService _sutaService;
        public SutaController(ISutaService sutaService)
        {
            _sutaService = sutaService;
        }

        [HttpGet, Route("api/student/GetStudents")]
        
       
        public IEnumerable<Suta> GetStudents()
        {
            return _sutaService.GetStudents();
        }



        [HttpGet, Route("api/student/InsertStudentData/{Name},{type}")]
       

        public IEnumerable<Suta> InsertStudentData(string Name, int type)
        {
            if (_sutaService.InsertStudent(Name, type))
            {
                return _sutaService.GetStudents();
            }

            return Enumerable.Empty<Suta>();
        }

        [HttpGet, Route("api/student/UpdateToNextClass/{TokenNo}")]
        public IEnumerable<Suta> UpdateToNextClass(int TokenNo)
        {
            if (_sutaService.UpdateStudentToNextClass(TokenNo))
            {
                return _sutaService.GetStudents().Where(s => s.TokenNo == TokenNo);
            }

            return Enumerable.Empty<Suta>();
        }

        [HttpGet, Route("api/student/DeleStudent/{TokenNo}")]
        public IEnumerable<Suta> DeleStudent(int TokenNo)
        {
            if (_sutaService.DeleteStudent(TokenNo))
            {
                return _sutaService.GetStudents();
            }

            return Enumerable.Empty<Suta>();
        }
    }
}
