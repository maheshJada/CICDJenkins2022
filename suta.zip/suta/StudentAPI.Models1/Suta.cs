﻿using System;

namespace SutaAPI.Models1
{
    public class Suta
    {
        public int TokenNo { get; set; }
        public string Name { get; set; }
        public int type { get; set; }
        public string Email { get; set; }
        public int PhoneNumber { get; set; }
        public string Gender { get; set; }
        public string Password { get; set; }
    }
}
