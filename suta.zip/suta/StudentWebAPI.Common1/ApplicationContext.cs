﻿using System;

namespace SutaWebAPI.Common1
{
    public class ApplicationContext
    {
        public static string ConnectionString = "server=IM-RT-LP-676\\SQLEXPRESS;database=AspireTest;integrated security=True";

    }
}
