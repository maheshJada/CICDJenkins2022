﻿using System;
using System.Collections.Generic;
using System.Text;
using SutaWebAPI.Common1;
using SutaWebAPI.Common1.Exceptions;
using SutaWebAPI;

namespace SutaWebAPI.Common1.Exceptions
{
   
       public class SutaException : Exception
    {
        public SutaException()
        {

        }

        public SutaException(string message) : base(message)
        {

        }

        public SutaException(string message, Exception innerEx) : base(message, innerEx)
        {

        }
    }
}
