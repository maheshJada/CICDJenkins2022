﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCoreWithInterface.Model;

namespace WebApiCoreWithInterface.Repository
{
    public interface IEmployee
    {
        IEnumerable<EmployeeM> GetAllEmployee();
        IEnumerable<EmployeeM> InsertEmployee(EmployeeM employee);
        bool Delete(int EmpId);
        EmployeeM GetById(int Id);
    }
}
