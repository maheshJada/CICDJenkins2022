﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCoreWithInterface.EmployeeContext;
using WebApiCoreWithInterface.Model;

namespace WebApiCoreWithInterface.Repository
{
    public class EmployeeService : IEmployee
    {
        private readonly EmpSqlContext _empSqlContext;
        public EmployeeService(EmpSqlContext empSqlContext)
        {
            _empSqlContext = empSqlContext;
        }
        public bool Delete(int EmpId)
        {

            var emp = _empSqlContext.EmployeeTable.Find(EmpId);
            if (emp == null)
                return false;
           _empSqlContext.Remove(emp);
           _empSqlContext.SaveChanges();
            return true;
        }

        public IEnumerable<EmployeeM> GetAllEmployee()
        {
          return  _empSqlContext.EmployeeTable;
        }

        public EmployeeM GetById(int Id)
        {
           return _empSqlContext.EmployeeTable.Find(Id);

            
        }

        public IEnumerable<EmployeeM> InsertEmployee(EmployeeM employee)
        {
            _empSqlContext.EmployeeTable.Add(employee);
            _empSqlContext.SaveChanges();
          return _empSqlContext.EmployeeTable;
        }

    }
}
