﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCoreWithInterface.EmployeeContext;
using WebApiCoreWithInterface.Model;
using WebApiCoreWithInterface.Repository;

namespace WebApiCoreWithInterface.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployee _EmpSalContext;
        public EmployeeController(IEmployee employee)
        {
            _EmpSalContext = employee;
        }
        [HttpGet]
        public IEnumerable<EmployeeM> GetEmployees()
        {
            return _EmpSalContext.GetAllEmployee();
        }
        [HttpPost, Route("Insert")]
        public IEnumerable<EmployeeM> Adding(EmployeeM employee)
        {
            return _EmpSalContext.InsertEmployee(employee);
        }
        [HttpDelete,Route("Delete")]
        public string Delete(int EmpId)
        {
            if(_EmpSalContext.Delete(EmpId) == true)
                return "Your succeffully deleted ";
            else
                return "User Not Found";
        }
        [HttpGet, Route("id")]
        public IActionResult Particularid(int Id)
        {
            EmployeeM obj = new EmployeeM();
            obj = _EmpSalContext.GetById(Id);
            if (obj == null)
            {
                return NotFound("Unable to find the data");
            }
            return Ok(obj);
        }
    }
}
