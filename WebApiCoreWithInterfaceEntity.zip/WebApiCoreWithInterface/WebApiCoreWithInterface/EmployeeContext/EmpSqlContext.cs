﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCoreWithInterface.Model;

namespace WebApiCoreWithInterface.EmployeeContext
{
    public class EmpSqlContext:DbContext
    {
        public EmpSqlContext(DbContextOptions<EmpSqlContext> options) : base(options)
        {

        }
        public DbSet<EmployeeM> EmployeeTable { get; set; }
    }
}
