﻿using System;

namespace StudentAPI.Models1
{
    public class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Class { get; set; }
    }
}
