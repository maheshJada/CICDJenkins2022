﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using StudentWebAPI1.Controllers;

using StudentWebAPI.Repository1;
using StudentAPI.Models1;

namespace StudentWebAPI1.Controllers
{
    public class StudentController : ControllerBase
    {
        private readonly IStudentService _studentService;
        public StudentController(IStudentService studentService)
        {
            _studentService = studentService;
        }

        [HttpGet, Route("api/student/GetStudents")]
        public IEnumerable<Student> GetStudents()
        {
            return _studentService.GetStudents();
        }



        [HttpGet, Route("api/student/InsertStudentData/{Name}/{Class}")]
        public IEnumerable<Student> InsertStudentData(Student student)
        {
            if (_studentService.InsertStudent(student))
            {
                return _studentService.GetStudents();
            }

            return Enumerable.Empty<Student>();
        }

        [HttpGet, Route("api/student/UpdateToNextClass/{rollNumber}")]
        public IEnumerable<Student> UpdateToNextClass(int rollNumber)
        {
            if (_studentService.UpdateStudentToNextClass(rollNumber))
            {
                return _studentService.GetStudents().Where(s => s.Id == rollNumber);
            }

            return Enumerable.Empty<Student>();
        }

        [HttpGet, Route("api/student/DeleStudent/{rollNumber}")]
        public IEnumerable<Student> DeleStudent(int rollNumber)
        {
            if (_studentService.DeleteStudent(rollNumber))
            {
                return _studentService.GetStudents();
            }

            return Enumerable.Empty<Student>();
        }
    }
}
