﻿using StudentAPI.Models1;
using System;
using System.Collections.Generic;

namespace StudentWebAPI.Repository1
{
    public interface IStudentService
    {
        IEnumerable<Student> GetStudents();
        bool UpdateStudentToNextClass(int rollNumber);
        bool InsertStudent(Student student);
         bool DeleteStudent(int rollNumber);
        //public void  DeleteStudent(string Name);
    }
}
