﻿using StudentAPI.Models1;
using StudentWebAPI.Common1;
using StudentWebAPI.Common1.Exceptions;

using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;



namespace StudentWebAPI.Repository1
{
    public class StudentService : IStudentService
    {
        private SqlConnection _connection;
        private SqlCommand _command;

        public StudentService()
        {
            _connection = new SqlConnection(ApplicationContext.ConnectionString);
        }


        public bool DeleteStudent(int rollNumber)
        {
            bool isSuccess = false;
            try
            {
                using (_command = new SqlCommand($"DELETE FROM Student WHERE Id = {rollNumber}", _connection))
                {
                    if (_connection.State == System.Data.ConnectionState.Closed)
                        _connection.Open();

                    _command.ExecuteNonQuery();

                    isSuccess = true;
                }
            }
            catch (Exception ex)
            {
                throw new StudentException(ex.Message, ex);
                //Console.WriteLine(ex1.Message);
            }
            finally
            {
                if (_connection.State == System.Data.ConnectionState.Open)
                    _connection.Close();
            }
            return isSuccess;
        }

        public bool InsertStudent(Student student)
        {
            bool isSuccess = false;
            try
            {
                using (_command = new SqlCommand($"INSERT INTO Student (Name, Class) VALUES ('{student.Name}', {student.Class})", _connection))
                {
                    if (_connection.State == System.Data.ConnectionState.Closed)
                        _connection.Open();

                    _command.ExecuteNonQuery();

                    isSuccess = true;
                }
            }
            catch (Exception ex)
            {
                throw new StudentException(ex.Message, ex);
                //Console.WriteLine(ex2.Message);
            }
            finally
            {
                if (_connection.State == System.Data.ConnectionState.Open)
                    _connection.Close();
            }

            return isSuccess;
        }

        public bool UpdateStudentToNextClass(int rollNumber)
        {
            bool isSuccess = false;
            try
            {
                using (_command = new SqlCommand($"UPDATE Student SET Class = Class + 1 WHERE Id = {rollNumber}", _connection))
                {
                    if (_connection.State == System.Data.ConnectionState.Closed)
                        _connection.Open();

                    _command.ExecuteNonQuery();

                    isSuccess = true;
                }
            }
            catch (Exception ex)
            {
                throw new StudentException(ex.Message, ex);
            }
            finally
            {
                if (_connection.State == System.Data.ConnectionState.Open)
                    _connection.Close();
            }
            return isSuccess;
        }

        public IEnumerable<Student> GetStudents()
        {
            List<Student> _students = new List<Student>();

            try
            {
                using (_command = new SqlCommand("SELECT * FROM Student", _connection))
                {
                    if (_connection.State == System.Data.ConnectionState.Closed)
                        _connection.Open();

                    SqlDataReader reader = _command.ExecuteReader();

                    while (reader?.Read() ?? false)
                        _students.Add(new Student() { Id = reader.GetInt32(0), Class = reader.GetInt32(1) ,Name = reader.GetString(2) });
                }
            }
            catch (Exception ex)
            {
                throw new StudentException(ex.Message, ex);
               //Console.WriteLine(ex.Message);
            }
            finally
            {
                if (_connection.State == System.Data.ConnectionState.Open)
                    _connection.Close();
            }

            return _students;
        }
    }
}
