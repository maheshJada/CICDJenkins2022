import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ApiService } from '../shared/api.service';
import { EmployeeModel } from './employee-dash-board.model';

@Component({
  selector: 'app-employee-dash-board',
  templateUrl: './employee-dash-board.component.html',
  styleUrls: ['./employee-dash-board.component.css']
})
export class EmployeeDashBoardComponent implements OnInit {

  mahir!:FormGroup;
  emplyeeModelObj:EmployeeModel=new EmployeeModel();
  employeeData !:any;
  showAdd !:boolean;
  showUpdate !:boolean;

  constructor(private _fBuilder:FormBuilder,
    private api:ApiService) { }

  ngOnInit(): void {
    this.mahir=this._fBuilder.group({
    firstName:[''],
    lastName:[''],
    email:[''],
    mobile:[''],
    salary:['']
  })

  this.getAllEmployee();
  }
  clickAddEmployee(){
    this.mahir.reset();
    this.showAdd=true;
    this.showUpdate=false;
  }
  postEmployeeDetails(){
    this.emplyeeModelObj.firstName=this.mahir.value.firstName;
    this.emplyeeModelObj.lastName=this.mahir.value.lastName;
    this.emplyeeModelObj.email=this.mahir.value.email;
    this.emplyeeModelObj.mobile=this.mahir.value.mobile;
    this.emplyeeModelObj.salary=this.mahir.value.salary;

    this.api.postEmployee(this.emplyeeModelObj)
    .subscribe(res=>{
      console.log(res);
      alert("Employee Added Succefully")
      let ref=document.getElementById('cancel');
      ref?.click();
      this.mahir.reset();
      this.getAllEmployee();
    },
    err=>{
      alert("something went wrong");
    })
  }

  getAllEmployee(){
    this.api.getEmployee()
    .subscribe(res=>{
      this.employeeData=res;
    })
  }

  deleteEmployee(row:any){
    this.api.deleteEmployee(row.id)
    .subscribe(res=>{
      alert("Employee Deleted")
      this.getAllEmployee();
    })
  }
  onEdit(row:any){
    this.showAdd=false;
    this.showUpdate=true;

    this.emplyeeModelObj.id=row.id

    this.mahir.controls['firstName'].setValue(row.firstName);
    this.mahir.controls['lastName'].setValue(row.lastName);
    this.mahir.controls['email'].setValue(row.email);
    this.mahir.controls['mobile'].setValue(row.mobile);
    this.mahir.controls['salary'].setValue(row.salary);
  }

  updateEmployeeDetails(){
    this.emplyeeModelObj.firstName=this.mahir.value.firstName;
    this.emplyeeModelObj.lastName=this.mahir.value.lastName;
    this.emplyeeModelObj.email=this.mahir.value.email;
    this.emplyeeModelObj.mobile=this.mahir.value.mobile;
    this.emplyeeModelObj.salary=this.mahir.value.salary;

    this.api.updateEmployee(this.emplyeeModelObj,this.emplyeeModelObj.id)
    .subscribe(res=>{
      alert("updated succefully")
      let ref=document.getElementById('cancel');
      ref?.click();
      this.mahir.reset();
      this.getAllEmployee();
    })
    
  }
}
