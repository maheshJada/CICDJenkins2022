﻿
using System;
using System.Collections.Generic;
using System.Linq;
using WebApiCore_CrudRest_AspnetCoreWebapi_.Model;

namespace WebApiCore_CrudRest_AspnetCoreWebapi_.EmployeeData
{
    public class MockEmployeeData : IEmployeeData
    {
        private List<Employee> employees = new List<Employee>()
        {
            new Employee()
            {
                ID=Guid.NewGuid(),
                Name="Employee One"
            },
            new Employee()
            {
                ID=Guid.NewGuid(),
                Name="Employee Two"
            },
        };
        public Employee AddEmployee(Employee employee)
        {
            employee.ID = Guid.NewGuid();
            employees.Add(employee);
            return employee;
        }

        public void DeleteEmployee(Employee employee)
        {
            employees.Remove(employee);
        }

        public Employee EditEmployee(Employee employee)
        {
            var exstingEmployee = GetEmployee(employee.ID);
            exstingEmployee.Name = employee.Name;
            return exstingEmployee;

        }

        public Employee GetEmployee(Guid id)
        {
            return employees.SingleOrDefault(e=>e.ID==id);
        }

        public List<Employee> GetEmployees()
        {
            return employees;
        }
    }
}
