﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiCore_CrudRest_AspnetCoreWebapi_.Model
{
    public class Employee
    {
        public Guid ID { get; set; }
        //Guid represents tthe unique identifier
        public string Name { get; set; }
    }
}
