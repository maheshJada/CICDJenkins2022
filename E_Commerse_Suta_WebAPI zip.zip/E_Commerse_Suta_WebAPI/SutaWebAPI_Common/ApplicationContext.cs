﻿using System;

namespace SutaWebAPI_Common
{
    public class ApplicationContext
    {
        public static string ConnectionString = "server=IM-RT-LP-676\\SQLEXPRESS;database=AspireTest;integrated security=True";
    }
}
