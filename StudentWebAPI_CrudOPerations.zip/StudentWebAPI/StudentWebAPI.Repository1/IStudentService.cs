﻿using StudentAPI.Models1;
using System;
using System.Collections.Generic;

namespace StudentWebAPI.Repository1
{
    public interface IStudentService
    {
        IEnumerable<Student> GetStudents();
        bool UpdateStudentToNextClass(int Id);
        bool InsertStudent(string Name,int Class);
        bool DeleteStudent(int Id);
       
    }
}
