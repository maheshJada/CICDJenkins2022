﻿using StudentAPI.Models1;
using StudentWebAPI.Common1;
using StudentWebAPI.Common1.Exceptions;

using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;



namespace StudentWebAPI.Repository1
{
    //Here i wrote the Query for the Student Operations
    public class StudentService : IStudentService
    {
        private SqlConnection _connection;
        private SqlCommand _command;

        public StudentService()
        {
            _connection = new SqlConnection(ApplicationContext.ConnectionString);
        }

        public bool DeleteStudent(int Id)
        {
            bool delete = false;
            try
            {
                using (_command = new SqlCommand("delete from student  where Id='" + Id + "'", _connection))
                {
                    if (_connection.State == System.Data.ConnectionState.Closed)
                        _connection.Open();

                    _command.ExecuteNonQuery();

                    delete = true;
                }
            }
            catch (Exception e)
            {
                throw new StudentException(e.Message);
            }
            finally
            {
                _connection.Close();
            }
            return delete;
        }

        public bool InsertStudent(string Name, int Class)
        {
            bool insert = false;
            try
            {
                using (_command= new SqlCommand("insert into student values (" + Class + ",'" + Name + "')", _connection))
                {
                    if (_connection.State == System.Data.ConnectionState.Closed)
                        _connection.Open();

                    _command.ExecuteNonQuery();

                    insert = true;
                }
            }
            catch (Exception e)
            {
                throw new StudentException(e.Message);
            }
            finally
            {
                _connection.Close();
            }
            return insert;
        }

        public bool UpdateStudentToNextClass(int Id)
        {
            bool update = false;
            try
            {
                using (_command = new SqlCommand("update student set Class= class+1 where Id='" + Id + "'", _connection))
                {
                    if (_connection.State == System.Data.ConnectionState.Closed)
                        _connection.Open();

                    _command.ExecuteNonQuery();

                    update = true;
                }
            }
            catch (Exception e)
            {
                throw new StudentException(e.Message);
            }
            finally
            {
                _connection.Close();
            }
            return update;
        }

        public IEnumerable<Student> GetStudents()
        {
            List<Student> _students = new List<Student>();

            try
            {
                using (_command = new SqlCommand("SELECT * FROM Student", _connection))
                {
                    if (_connection.State == System.Data.ConnectionState.Closed)
                        _connection.Open();

                    SqlDataReader reader = _command.ExecuteReader();

                    while (reader?.Read() ?? false)
                        _students.Add(new Student() { Id = reader.GetInt32(0), Class = reader.GetInt32(1) ,Name = reader.GetString(2) });
                }
            }
            catch (Exception e)
            {
                throw new StudentException(e.Message);
            }
            finally
            {
                if (_connection.State == System.Data.ConnectionState.Open)
                    _connection.Close();
            }

            return _students;
        }
    }
}
