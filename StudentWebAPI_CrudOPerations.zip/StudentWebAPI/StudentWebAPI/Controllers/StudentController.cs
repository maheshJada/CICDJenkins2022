﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using StudentWebAPI1.Controllers;

using StudentWebAPI.Repository1;
using StudentAPI.Models1;

namespace StudentWebAPI1.Controllers
{
    public class StudentController : ControllerBase
    {
        private readonly IStudentService _studentService;
        public StudentController(IStudentService studentService)
        {
            _studentService = studentService;
        }

        [HttpGet, Route("api/student/GetStudents")]
        public IEnumerable<Student> GetStudents()
        {
            return _studentService.GetStudents();
        }



        [HttpGet, Route("api/student/InsertStudentData/{Name},{Class}")]
        public IEnumerable<Student> InsertStudentData(string Name, int Class)
        {
            if (_studentService.InsertStudent(Name, Class))
            {
                return _studentService.GetStudents();
            }

            return Enumerable.Empty<Student>();
        }

        [HttpGet, Route("api/student/UpdateToNextClass/{Id}")]
        public IEnumerable<Student> UpdateToNextClass(int Id)
        {
            if (_studentService.UpdateStudentToNextClass(Id))
            {
                return _studentService.GetStudents().Where(s => s.Id == Id);
            }

            return Enumerable.Empty<Student>();
        }

        [HttpGet, Route("api/student/DeleStudent/{Id}")]
        public IEnumerable<Student> DeleStudent(int Id)
        {
            if (_studentService.DeleteStudent(Id))
            {
                return _studentService.GetStudents();
            }

            return Enumerable.Empty<Student>();
        }
    }
}
