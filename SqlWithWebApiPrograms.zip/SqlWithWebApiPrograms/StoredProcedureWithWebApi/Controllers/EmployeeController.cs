﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StoredProcedureWithWebApi.Model;
using StoredProcedureWithWebApi.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StoredProcedureWithWebApi.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployee _employee;
        public EmployeeController(IEmployee employee)
        {
            _employee = employee;
        }
        [HttpPost]
        public bool AddData(Employee innomindsEmployees)
        {
            if (ModelState.IsValid)
            {
                _employee.InsertData(innomindsEmployees);

                return true;
            }
            return false;
        }

        [HttpDelete]
        public bool Delete(int id)
        {
            if (ModelState.IsValid)
            {
                _employee.Delete(id);

                return true;
            }
            return false;

        }
        [HttpGet]
        public IEnumerable<Employee>GetById(int id)
        {
          return  _employee.GetParticularData(id);
        }
        [HttpGet]
        public IEnumerable<Employee>GetAllData()
        {
            return _employee.GetAllEmployee();
        }
        [HttpPut]
        public bool UpdateTheData(Employee employees)
        {
            if (ModelState.IsValid)
            {
                _employee.Update(employees);
                return true;
            }
            else
            {
                return false;
            }

        }
    }
}
