﻿using StoredProcedureWithWebApi.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace StoredProcedureWithWebApi.Services
{
    public class EmployeeService : IEmployee
    {

        private SqlConnection _connection;
        private SqlCommand _command;
        public EmployeeService()
        {
            _connection = new SqlConnection(ApplicationContext.ConnectionString);

        }
        public bool Delete(int id)
        {
            try
            {
                using (_command = new SqlCommand("proc_Deleteemp", _connection))
                    if (_connection.State == System.Data.ConnectionState.Closed)
                    {

                        _connection.Open();
                        _command.CommandType = System.Data.CommandType.StoredProcedure;
                        _command.Parameters.AddWithValue("@eno", id);
                        _command.ExecuteNonQuery();
                        return true;
                    }
                return false;
            }
            catch (Exception)
            {
                throw new Exception();
            }
            finally
            {
                if (_connection.State == System.Data.ConnectionState.Open)
                {

                    _connection.Close();
                }
            }


        }

        public IEnumerable<Employee> GetAllEmployee()
        {
            List<Employee> Data = new List<Employee>();
            try
            {
                
                using (_command = new SqlCommand("proc_Geteemp", _connection))
                    if (_connection.State == System.Data.ConnectionState.Closed)
                        _connection.Open();
                _command.CommandType = CommandType.StoredProcedure;
                
                SqlDataReader reader = _command.ExecuteReader();
                while (reader.Read())
                {
                    Employee e = new Employee() { EmpId = reader.GetInt32(0), EmpName = reader.GetString(1), EmpSal = reader.GetInt32(2) };
                    Data.Add(e);

                }
            }
          
            finally
            {
                if (_connection.State == ConnectionState.Open)
                {
                    _connection.Close();
                }
            }
            return Data;
        }

        public IEnumerable<Employee> GetParticularData(int id)
        {
            try
            {
                List<Employee> Data = new List<Employee>();
                using (_command = new SqlCommand("proc_serchemp", _connection))
                    if (_connection.State == ConnectionState.Closed)
                    {
                        _connection.Open();
                        _command.CommandType =CommandType.StoredProcedure;
                        _command.Parameters.AddWithValue("@eno", id);
                        SqlDataReader dr = _command.ExecuteReader();
                        
                            while (dr.Read())
                            {
                                Employee e = new Employee()
                                {
                                    EmpId = dr.GetInt32(0),
                                    EmpName = dr.GetString(1),
                                    EmpSal = dr.GetInt32(2),
                                };
                                Data.Add(e);
                            }
                        
                       
                    }
                return Data;

            }
            catch
            {
                throw new Exception();
            }
            finally
            {
                if (_connection.State == ConnectionState.Open)
                {
                    _connection.Close();
                }
            }
        }

        public bool InsertData(Employee employees)
        {
            try
            {
                using (_command = new SqlCommand("proc_Addemp", _connection))
                    if (_connection.State == System.Data.ConnectionState.Closed)
                    {
                        _connection.Open();
                        _command.CommandType = System.Data.CommandType.StoredProcedure;
                        _command.Parameters.AddWithValue("@eno", employees.EmpId);
                        _command.Parameters.AddWithValue("@ename", employees.EmpName);
                        _command.Parameters.AddWithValue("@esal", employees.EmpSal);
                        _command.ExecuteNonQuery();
                        return true;
                    }
                return false;

            }
            catch (Exception)
            {
                throw new Exception();
            }
            finally
            {
                if (_connection.State == System.Data.ConnectionState.Open)
                {
                    _connection.Close();
                }

            }

        }

        public bool Update(Employee employee)
        {
            try
            {
                using (_command = new SqlCommand("proc_Updateemp", _connection))
                    if (_connection.State == System.Data.ConnectionState.Closed)
                    {
                        _connection.Open();
                        _command.CommandType = System.Data.CommandType.StoredProcedure;
                        _command.Parameters.AddWithValue("@eno", employee.EmpId);
                        _command.Parameters.AddWithValue("@ename", employee.EmpName);
                        _command.Parameters.AddWithValue("@esal", employee.EmpSal);
                        _command.ExecuteNonQuery();
                        return true;
                    }
                return false;
            }
            catch (Exception)
            {
                throw new Exception();
            }
            finally
            {
                if (_connection.State == System.Data.ConnectionState.Open)
                {
                    _connection.Close();
                }

            }
        }
    }
}
