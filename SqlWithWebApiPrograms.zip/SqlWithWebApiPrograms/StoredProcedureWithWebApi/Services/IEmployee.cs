﻿using StoredProcedureWithWebApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StoredProcedureWithWebApi.Services
{
    public interface IEmployee
    {
        IEnumerable<Employee> GetAllEmployee();
        IEnumerable<Employee> GetParticularData(int id);
        bool InsertData(Employee employees);
        bool Delete(int id);
        bool Update(Employee employee);
    }
}
