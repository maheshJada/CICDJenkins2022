﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SqlWithWebApiPrograms.Model
{
    public class ApplicationContext
    {
        public static string ConnectionString = "Data Source=IM-RT-LP-676\\SQLEXPRESS; Initial Catalog=AspireTest;Trusted_Connection=True;MultipleActiveResultSets=True";
    }
}
