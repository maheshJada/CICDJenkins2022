﻿
using SqlWithWebApiPrograms.Model;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace SqlWithWebApiPrograms.Services
{
    public class EmployeeService : IEmployee
    {
        private  SqlConnection _connection;
        private  SqlCommand _command;
        public EmployeeService()
        {
            _connection = new SqlConnection(ApplicationContext.ConnectionString);
            
        }
        
        public bool Delete(int id)
        {
            try
            {
                IEnumerable<InnomindsEmployees> list1 = GetParticularData(id);
                if (list1.Any(t=>t.EmpId==id))
                {
                    using (_command = new SqlCommand("delete from InnomindsEmployees where EmpId=" + id + "", _connection))
                        if (_connection.State == System.Data.ConnectionState.Closed)
                        {
                            _connection.Open();

                            _command.ExecuteNonQuery();
                            return true;
                        }
                }
                 
                return false;
            }
            
           catch (Exception )
            {
                throw new Exception();
            }
            finally
            {
                if (_connection.State == System.Data.ConnectionState.Open)
                    _connection.Close();
            }
           
        }

        public IEnumerable<InnomindsEmployees> GetAllEmployee()
        {
            List<InnomindsEmployees> _innominds = new List<InnomindsEmployees>();

            try
            {
                using (_command = new SqlCommand("select * from InnomindsEmployees ", _connection))
                    if (_connection.State == System.Data.ConnectionState.Closed)
                        _connection.Open();
                SqlDataReader reader = _command.ExecuteReader();
                while (reader.Read())
                {
                    InnomindsEmployees e = new InnomindsEmployees() { EmpId = reader.GetInt32(0), EmpName = reader.GetString(1), EmpSal = reader.GetInt32(2) };
                    _innominds.Add(e);

                }
            }
            catch(Exception )
            {
                throw new Exception();

            }
            finally
            {
                if (_connection.State == System.Data.ConnectionState.Open)
                    _connection.Close();
                
            }
            return _innominds;

        }

        public IEnumerable<InnomindsEmployees> GetParticularData(int id)
        {
            try
            {
                IEnumerable<InnomindsEmployees> ie1 = GetAllEmployee();

                List<InnomindsEmployees> _innominds = new List<InnomindsEmployees>();
                if (ie1.Any(t => t.EmpId == id))
                {                   
                        using (_command = new SqlCommand("select * from InnomindsEmployees where EmpId=" + id + "", _connection))
                            if (_connection.State == System.Data.ConnectionState.Closed)
                                _connection.Open();
                        SqlDataReader reader = _command.ExecuteReader();
                        while (reader.Read())
                        {
                            InnomindsEmployees e = new InnomindsEmployees() { EmpId = reader.GetInt32(0), EmpName = reader.GetString(1), EmpSal = reader.GetInt32(2) };
                            _innominds.Add(e);
                        }
                }

                return _innominds;
            }     
                catch (Exception)
                {
                    throw new Exception();
                }
                finally
                {
                    if (_connection.State == System.Data.ConnectionState.Open)
                        _connection.Close();
                }
        }

        public bool InsertData(InnomindsEmployees employees)
        {

            try
            {
                using (_command = new SqlCommand("insert into InnomindsEmployees values('" + employees.EmpId + "','" + employees.EmpName + "','" + employees.EmpSal + "')", _connection))

                    if (_connection.State == System.Data.ConnectionState.Closed)
                    {
                        _connection.Open();
                        _command.ExecuteNonQuery();

                        return true;
                    }
                return false;
            }
            catch(Exception)
            {
                throw new Exception(); 
            }
            finally
            {
                if (_connection.State == System.Data.ConnectionState.Closed)
                    _connection.Close();
            }
                    
        }

        public bool Update(InnomindsEmployees employee)
        {
            try
            {
                using (_command = new SqlCommand("update InnomindsEmployees set EmpName='"+ employee.EmpName+ "',EmpSal="+employee.EmpSal+ " where EmpID='" + employee.EmpId + "' ", _connection))
                    if (_connection.State == System.Data.ConnectionState.Closed)
                    {
                        _connection.Open();
                        _command.ExecuteNonQuery();
                        return true;
                    }
                return false;
            }

            catch (Exception)
            {
                throw new Exception();
            }
            finally
            {
                if (_connection.State == System.Data.ConnectionState.Open)
                    _connection.Close();
            }

        }
    }
}
