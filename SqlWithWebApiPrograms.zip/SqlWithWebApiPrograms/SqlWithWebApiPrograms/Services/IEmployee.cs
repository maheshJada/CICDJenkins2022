﻿using SqlWithWebApiPrograms.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SqlWithWebApiPrograms.Services
{
    public interface IEmployee
    {
        IEnumerable<InnomindsEmployees> GetAllEmployee();
        IEnumerable<InnomindsEmployees> GetParticularData(int id);
        bool InsertData(InnomindsEmployees employees);
        bool Delete(int id);
        bool Update(InnomindsEmployees employee);
    }
}
