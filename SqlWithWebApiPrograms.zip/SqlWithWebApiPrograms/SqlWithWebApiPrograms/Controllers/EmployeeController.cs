﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SqlWithWebApiPrograms.Model;
using SqlWithWebApiPrograms.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SqlWithWebApiPrograms.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployee _employee;
        public EmployeeController(IEmployee employee)
        {
            _employee = employee;
        }
        [HttpPost]
        public bool AddData(InnomindsEmployees innomindsEmployees)
        {
            if(ModelState.IsValid)
            {
                _employee.InsertData(innomindsEmployees);

                return true;
            }
            return false;
        }
        [HttpGet]
        public IEnumerable<InnomindsEmployees>GetTheData()
        {
          return  _employee.GetAllEmployee();
        }
        [HttpGet]
        public IEnumerable<InnomindsEmployees> GetById(int id)
        {
            return _employee.GetParticularData(id);
        }
        [HttpDelete]
        public bool DeleteTheData(int id)
        {
            if (ModelState.IsValid)
            {
                if (_employee.Delete(id) == true)
                    return true;
                else
                    return false;


            }
            else
            {
                return false;
            }
        }
        [HttpPut]
        public bool UpdateTheData(InnomindsEmployees employees)
        {
            if (ModelState.IsValid)
            {
                _employee.Update(employees);
                return true;
            }
            else
            {
                return false;
            }

        }
    }
}
