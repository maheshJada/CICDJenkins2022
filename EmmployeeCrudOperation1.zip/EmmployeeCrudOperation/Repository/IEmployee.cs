﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public interface IEmployee
    {
        IEnumerable<UsersData> GetRegistaredData();
        bool Registraion(UsersData Cust_deatils);
        bool LoginCustomer(string Name, string Password);
        IEnumerable<Employee> GetAllEmployee();
        IEnumerable<Employee> GetParticularData(int id);
        bool InsertData(Employee employees);
        bool Delete(int id);
        bool Update(Employee employee);
    }
}
