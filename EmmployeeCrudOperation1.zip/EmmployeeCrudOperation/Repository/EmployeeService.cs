﻿using Model;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public class EmployeeService:IEmployee
    {

        private SqlConnection _connection;
        private SqlCommand _command;
        public EmployeeService()
        {
            _connection = new SqlConnection(ApplicationContext.ConnectionString);

        }


        public IEnumerable<UsersData> GetRegistaredData()
        {
            List<UsersData> _GetSuta = new List<UsersData>();

            try
            {
                using (_command = new SqlCommand("select  * from Registaration", _connection))
                {
                    if (_connection.State == System.Data.ConnectionState.Closed)
                        _connection.Open();

                    SqlDataReader reader = _command.ExecuteReader();

                    while (reader?.Read() ?? false)
                        _GetSuta.Add(new UsersData() { Name = reader.GetString(0), Email = reader.GetString(1), PhoneNumber = reader.GetInt32(2), Gender = reader.GetString(3), Password = reader.GetString(4) });
                }
            }
            catch (Exception )
            {
                throw new Exception();
            }
            finally
            {
                if (_connection.State == System.Data.ConnectionState.Open)
                    _connection.Close();
            }

            return _GetSuta;
        }


        public bool Registraion(UsersData Cust_deatils)
        {
            bool insert = false;
            try
            {
                using (_command = new SqlCommand("insert into Registaration values('" + Cust_deatils.Name + "','" + Cust_deatils.Email + "','" + Cust_deatils.PhoneNumber + "','" + Cust_deatils.Gender + "','" + Cust_deatils.Password + "')", _connection))
                {
                    if (_connection.State == System.Data.ConnectionState.Closed)
                        _connection.Open();

                    _command.ExecuteNonQuery();

                    insert = true;
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
            finally
            {
                _connection.Close();
            }
            return insert;
        }

        /// <summary>
        /// This Method is used for login 
        /// </summary>
        /// <param name="Name"></param>
        /// <param name="Password"></param>
        /// <returns>It will open the website</returns>
        public bool LoginCustomer(string Name, string Password)
        {
            bool IsLogin = false;
            try
            {
                using (_command = new SqlCommand(" select * from Registaration where Name='" + Name + "' ", _connection))
                {
                    if (_connection.State == System.Data.ConnectionState.Closed)
                        _connection.Open();

                    SqlDataReader dr = _command.ExecuteReader();
                    while (dr.Read())
                    {
                        if (Password.Equals(dr["Password"]))
                            IsLogin = true;
                    }
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
            finally
            {
                _connection.Close();
            }
            return IsLogin;

        }

        public bool Delete(int id)
        {
            try
            {
                IEnumerable<Employee> list1 = GetParticularData(id);
                if (list1.Any(t => t.EmpId == id))
                {
                    using (_command = new SqlCommand("delete from InnomindsEmployees where EmpId=" + id + "", _connection))
                        if (_connection.State == System.Data.ConnectionState.Closed)
                        {
                            _connection.Open();

                            _command.ExecuteNonQuery();
                            return true;
                        }
                }

                return false;
            }

            catch (Exception)
            {
                throw new Exception();
            }
            finally
            {
                if (_connection.State == System.Data.ConnectionState.Open)
                    _connection.Close();
            }

        }

        public IEnumerable<Employee> GetAllEmployee()
        {
            List<Employee> _innominds = new List<Employee>();

            try
            {
                using (_command = new SqlCommand("select * from InnomindsEmployees ", _connection))
                    if (_connection.State == System.Data.ConnectionState.Closed)
                        _connection.Open();
                SqlDataReader reader = _command.ExecuteReader();
                while (reader.Read())
                {
                    Employee e = new Employee() { EmpId = reader.GetInt32(0), EmpName = reader.GetString(1), EmpSal = reader.GetInt32(2) };
                    _innominds.Add(e);

                }
            }
            catch (Exception)
            {
                throw new Exception();

            }
            finally
            {
                if (_connection.State == System.Data.ConnectionState.Open)
                    _connection.Close();

            }
            return _innominds;

        }

        public IEnumerable<Employee> GetParticularData(int id)
        {
            try
            {
                IEnumerable<Employee> ie1 = GetAllEmployee();

                List<Employee> _innominds = new List<Employee>();
                if (ie1.Any(t => t.EmpId == id))
                {
                    using (_command = new SqlCommand("select * from InnomindsEmployees where EmpId=" + id + "", _connection))
                        if (_connection.State == System.Data.ConnectionState.Closed)
                            _connection.Open();
                    SqlDataReader reader = _command.ExecuteReader();
                    while (reader.Read())
                    {
                        Employee e = new Employee() { EmpId = reader.GetInt32(0), EmpName = reader.GetString(1), EmpSal = reader.GetInt32(2) };
                        _innominds.Add(e);
                    }
                }

                return _innominds;
            }
            catch (Exception)
            {
                throw new Exception();
            }
            finally
            {
                if (_connection.State == System.Data.ConnectionState.Open)
                    _connection.Close();
            }
        }

        public bool InsertData(Employee employees)
        {

            try
            {
                using (_command = new SqlCommand("insert into InnomindsEmployees values('" + employees.EmpId + "','" + employees.EmpName + "','" + employees.EmpSal + "')", _connection))

                    if (_connection.State == System.Data.ConnectionState.Closed)
                    {
                        _connection.Open();
                        _command.ExecuteNonQuery();

                        return true;
                    }
                return false;
            }
            catch (Exception)
            {
                throw new Exception();
            }
            finally
            {
                if (_connection.State == System.Data.ConnectionState.Closed)
                    _connection.Close();
            }

        }

        public bool Update(Employee employee)
        {
            try
            {
                using (_command = new SqlCommand("update InnomindsEmployees set EmpName='" + employee.EmpName + "',EmpSal=" + employee.EmpSal + " where EmpID='" + employee.EmpId + "' ", _connection))
                    if (_connection.State == System.Data.ConnectionState.Closed)
                    {
                        _connection.Open();
                        _command.ExecuteNonQuery();
                        return true;
                    }
                return false;
            }

            catch (Exception)
            {
                throw new Exception();
            }
            finally
            {
                if (_connection.State == System.Data.ConnectionState.Open)
                    _connection.Close();
            }

        }
    }
}
