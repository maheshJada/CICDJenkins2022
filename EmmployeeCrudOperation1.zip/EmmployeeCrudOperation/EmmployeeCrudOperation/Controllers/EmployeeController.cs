﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Model;
using Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeCrudOperation.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployee _employee;
        public EmployeeController(IEmployee employee)
        {
            _employee = employee;
        }
        [HttpGet]
        public IEnumerable<UsersData> GetSutaDetails()
        {
            return _employee.GetRegistaredData();
        }

        [HttpPost]
        public IEnumerable<UsersData> Register(UsersData inserteddata)
        {
            if (_employee.Registraion(inserteddata))
            {
                return _employee.GetRegistaredData();
            }

            return Enumerable.Empty<UsersData>();
        }
        //This is the End Point for the login

        [HttpPost]

        public bool LoginCustomer(string Name, string Password)
        {
            if (_employee.LoginCustomer(Name, Password))
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        [HttpPost]
        public bool AddData(Employee innomindsEmployees)
        {
            if (ModelState.IsValid)
            {
                _employee.InsertData(innomindsEmployees);

                return true;
            }
            return false;
        }
        [HttpGet]
        public IEnumerable<Employee> GetTheData()
        {
            return _employee.GetAllEmployee();
        }
        [HttpGet]
        public IEnumerable<Employee> GetById(int id)
        {
            return _employee.GetParticularData(id);
        }
        [HttpDelete]
        public bool DeleteTheData(int id)
        {
            if (ModelState.IsValid)
            {
                if (_employee.Delete(id) == true)
                    return true;
                else
                    return false;


            }
            else
            {
                return false;
            }
        }
        [HttpPut]
        public bool UpdateTheData(Employee employees)
        {
            if (ModelState.IsValid)
            {
                _employee.Update(employees);
                return true;
            }
            else
            {
                return false;
            }

        }
    }
}
