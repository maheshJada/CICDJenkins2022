﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Model
{
    public class Employee
    {
        [Required]
        public int EmpId { get; set; }

        [Required(ErrorMessage = "EmpName is required")]
        [StringLength(20, ErrorMessage = "EmpName can't be longer than 20 characters")]
        public string EmpName { get; set; }

        [Required]
        public int EmpSal { get; set; }
    }

    public class UsersData
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public int PhoneNumber { get; set; }
        public string Gender { get; set; }
        public string Password { get; set; }
    }
}
