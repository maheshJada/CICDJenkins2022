﻿using System;
using System.Xml.Linq;
using System.IO;

namespace studentdata
{
    public class studentRead
    {
        public void data(XElement Students,int Class,string Name,string PhoneNumber)
        {
            Students.Add(new XElement("student",
                               new XAttribute("class", Class),
                                new XElement("Name", Name),
                                 new XElement("mobile", PhoneNumber))
                         );
            string path = "D:/mahesh/studentDetails.xml";
            Students.Save(path);
            Console.ReadLine();

        }
    }
}
