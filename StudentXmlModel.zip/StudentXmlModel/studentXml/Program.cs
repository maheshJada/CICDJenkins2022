﻿using System;
using System.Linq;
using System.Xml.Linq;
using studentdata;
using studentxml;


namespace studentxml
{
    public class Program
    {
        static void Main(string[] args)
        {
            XElement Students =
               new XElement("students");
            int Class = 1;
            string Name = "";
            string PhoneNumber = "";
           Console.WriteLine("Enter the Number of students:");
            int n = int.Parse(Console.ReadLine());
           
                for (int i = 1; i <= n; i++)
                {
                    studentRead Sr = new studentRead();
                Cdata:
                try
                {
                    Console.WriteLine("Enter The class");
                    Class = int.Parse(Console.ReadLine());
                    if (!Enum.IsDefined(typeof(Enumclass), Class) == true)
                        throw new studentClassExceptions("Please Enter the class is 1-10");
                }
                catch(studentClassExceptions sc)
                {
                    Console.WriteLine(sc.Message);
                    goto Cdata;
                }
                catch(FormatException e1)
                {
                    Console.WriteLine(e1.Message);
                    goto Cdata;
                }
                CName:
                try
                {

                    Console.WriteLine("Enter the Name:");
                     Name = Console.ReadLine();
                    if (string.IsNullOrWhiteSpace(Name) == true)
                        throw new StudentCanNotBeNull("Student Name cannot be null:");
                    if (Name.Any(sn => char.IsLetter(sn) == false))
                        throw new StudentCanNotBeNull("Student  cannot be digits and symbols:");

                }
                catch(StudentCanNotBeNull scn)
                {
                    Console.WriteLine(scn.Message);
                    goto CName;
                }
                catch (FormatException e2)
                {
                    Console.WriteLine(e2.Message);
                    goto CName;

                }
            Cphone:
                try
                {
                    Console.WriteLine("Enter the Phone Number:");
                     PhoneNumber = Console.ReadLine();
                    if (string.IsNullOrWhiteSpace(PhoneNumber) == true)
                        throw new StudentNumberCanNotBeNull("Student Phone Number cannot be null:");
                    if (PhoneNumber.Any(sn => char.IsLetter(sn) == true))
                        throw new StudentNumberCanNotBeNull("Student Number can be alphabet ");
                }
                catch (StudentNumberCanNotBeNull scn)
                {
                    Console.WriteLine(scn.Message);
                    goto Cphone;
                }
                catch (FormatException e3)
                {
                    Console.WriteLine(e3.Message);
                    goto Cphone;
                }
                Sr.data(Students, Class, Name, PhoneNumber);
                }
            Console.WriteLine(Students);
        }
    }
}
