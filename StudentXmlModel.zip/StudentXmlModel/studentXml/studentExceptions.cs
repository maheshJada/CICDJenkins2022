﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace studentxml
{
  public  class studentNameExceptions : Exception
    {
        public studentNameExceptions()
        {
        }

        public studentNameExceptions(string message) : base(message)
        {
        }

        public studentNameExceptions(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected studentNameExceptions(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }

    public class studentClassExceptions : Exception
    {
        public studentClassExceptions()
        {
        }

        public studentClassExceptions(string message) : base(message)
        {
        }

        public studentClassExceptions(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected studentClassExceptions(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
    public class StudentNumberCanNotBeNull : Exception
    {
        public StudentNumberCanNotBeNull()
        {
        }

        public StudentNumberCanNotBeNull(string message) : base(message)
        {
        }

        public StudentNumberCanNotBeNull(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected StudentNumberCanNotBeNull(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
    public class StudentCanNotBeNull : Exception
    {
        public StudentCanNotBeNull()
        {
        }

        public StudentCanNotBeNull(string message) : base(message)
        {
        }

        public StudentCanNotBeNull(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected StudentCanNotBeNull(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }


}
