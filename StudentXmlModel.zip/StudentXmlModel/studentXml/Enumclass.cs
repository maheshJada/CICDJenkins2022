﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace studentxml
{
    public enum Enumclass
    {
        Class1=1,
        class2,
        class3,
        class4,
        class5,
        class6,
        class7,
        class8,
        class9,
        class10

    }
}
