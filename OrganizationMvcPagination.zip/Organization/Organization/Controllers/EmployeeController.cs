﻿using Microsoft.AspNetCore.Mvc;
using Organization.Models;
using Organization.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using ReflectionIT.Mvc.Paging;


namespace Organization.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly IEmployee Employee;
        

        public EmployeeController(IEmployee employee)
        {
            Employee = employee;
        }
        //public IActionResult Index()
        //{
        //    var obj = Employee.GetEmployee();

        //    return View(obj);
        //}
        public IActionResult Index(int pg=1)
        {
            List<Empoloyee> employee = Employee.GetEmployee();
            int pageSize = 2;
            if (pg < 1)
                pg = 1;
            int resCount = employee.Count();
            var pager = new Pager(resCount, pg, pageSize);
            int recSkip = (pg - 1) * pageSize;
            var data = employee.Skip(recSkip).Take(pager.PageSize).ToList();
            this.ViewBag.Pager = pager;
            return View(data);
        }

        //public async Task<IActionResult> Index(int page = 1, string sortExpression = "EmpId")
        //{
        //    var obj = Employee.GetEmployee().AsQueryable().AsNoTracking();
        //    var model =  PagingList<Empoloyee>.CreateAsync(obj, 10, page, sortExpression, "EmpId");
        //    return View(model);
        //}

        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(Empoloyee e1)
        {
            string data = Employee.AddEmployee(e1);
            if (data != null)
            {
                return RedirectToAction("Index");
            }

            return View(e1);
        }
        [HttpGet]
        public ActionResult Delete(int id)
        {
            Empoloyee e1 = new Empoloyee();
            e1.EmpId = id;
            e1 = Employee.searchEmp(e1);
            return View(e1);
        }
        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConform(int id)
        {
            Empoloyee e1 = new Empoloyee();
            e1.EmpId = id;
            var m= Employee.DeleteEmployee(e1);
            if (m == true)
            {
                return RedirectToAction("Index");
            }
            return View(e1);
        }

        [HttpPost,  ActionName("Edit")]
        public ActionResult Edit(Empoloyee empoloyee)
        {
            var m = Employee.UpdateEmployee(empoloyee);
            if (m == 1)
            {
                return RedirectToAction("Index");
            }
            return View(empoloyee);
        }

       [HttpGet]
        public ActionResult Edit(int id)
        {

            Empoloyee e1 = new Empoloyee();
            e1.EmpId = id;
            e1 = Employee.searchEmp(e1);
            return View(e1);
        }
        [HttpGet]
        public ActionResult Details(int id)
        {

            Empoloyee e1 = new Empoloyee();
            e1.EmpId = id;
            e1 = Employee.searchEmp(e1);
            return View(e1);
        }
    }
}
