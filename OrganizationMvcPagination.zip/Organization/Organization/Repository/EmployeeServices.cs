﻿using Microsoft.Extensions.Configuration;
using Organization.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Data;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Organization.Repository
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class EmployeeServices : IEmployee
    {
        private SqlConnection _connection;
        private IConfiguration _configuration;
        public EmployeeServices(IConfiguration configuration)
        {
            _configuration = configuration;
            _connection = new SqlConnection(configuration.GetConnectionString("defaultconnection"));

        }

        
        [HttpPost]
        public string AddEmployee(Empoloyee e1)
        {
            
            {
                _connection.Open();
                SqlCommand cmd = new SqlCommand("proc_Insert", _connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmpName", e1.EmpName);
                cmd.Parameters.AddWithValue("@DepartmentName", e1.DepartmentName);
                cmd.Parameters.AddWithValue("@Address", e1.Address);
                int i = cmd.ExecuteNonQuery();
                _connection.Close();
                return "Employee Added Succefully";
            }
        }

        [HttpDelete]
        public bool DeleteEmployee(Empoloyee e1)
        {
            _connection.Open();
            SqlCommand cmd = new SqlCommand("DeletestoredData", _connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@EmpId", e1.EmpId);
            int i = cmd.ExecuteNonQuery();
            _connection.Close();
            return true;
        }
        [HttpPut]
        public int UpdateEmployee(Empoloyee e1)
        {
            _connection.Open();
            SqlCommand cmd = new SqlCommand("UpdateTheData", _connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@EmpId", e1.EmpId);
            cmd.Parameters.AddWithValue("@EmpName", e1.EmpName);
            cmd.Parameters.AddWithValue("@DepartmentName", e1.DepartmentName);
            cmd.Parameters.AddWithValue("@Address", e1.Address);
            int i = cmd.ExecuteNonQuery();
            _connection.Close();
            return i;
        }
        [HttpGet]
        public List<Empoloyee> GetEmployee()
        {
            List<Empoloyee> li = new List<Empoloyee>();
            _connection.Open();
            SqlCommand cmd = new SqlCommand("proc_GetOrg", _connection);
            SqlDataReader dr = cmd.ExecuteReader();
           
                while (dr.Read())
                {
                    Empoloyee e1 = new Empoloyee();
                    e1.EmpId = int.Parse(dr[0].ToString());
                    e1.EmpName = dr[1].ToString();
                    e1.Address= dr[2].ToString();
                    e1.DepartmentName = dr[3].ToString();
                li.Add(e1);
                }
           

            return li;
        }

       
        [HttpGet]
        public Empoloyee searchEmp(Empoloyee e1)
        {
            _connection.Open();
            SqlCommand cmd = new SqlCommand("proc_Search", _connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@EmpId", e1.EmpId);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                if (dr.Read())
                {
                    e1.EmpName = dr[1].ToString();
                    e1.DepartmentName = dr[3].ToString();
                    e1.Address = dr[2].ToString();

                }
            }
            _connection.Close();
            return e1;
        }
    }
}
