﻿using Organization.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Organization.Repository
{
    public interface IEmployee
    {
        List<Empoloyee> GetEmployee();

        string AddEmployee(Empoloyee e1);

        Empoloyee searchEmp(Empoloyee id);
        int UpdateEmployee(Empoloyee e1);

        bool DeleteEmployee(Empoloyee e1);

    }
}
