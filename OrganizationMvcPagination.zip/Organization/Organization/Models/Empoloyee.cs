﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Organization.Models
{
    public class Empoloyee
    {
        
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public string Address { get; set; }
        public string DepartmentName { get; set; }
    }
}
