﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

public enum RegistrationStatus
{
    UserExists,
    UserCreationFailed,
    UserCreationSuccess
}
namespace Organization.Models
{
    public class UserData
    {
        public string UserName { get; set; }
        public string Email { get; set; }
        public string Role { get; set; }
        public string Password { get; set; }
    }
    public class Login
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
    public class Response
    {
        public string Status { get; set; }
        public string Message { get; set; }
    }
    public class LoginReponse
    {
        public string Token { get; set; }
        public DateTime Expiration { get; set; }
        public bool Success { get; set; }
    }
    public class UserRegistrationResponse
    {
        public RegistrationStatus RegistrationStatus { get; set; }
    }
}
