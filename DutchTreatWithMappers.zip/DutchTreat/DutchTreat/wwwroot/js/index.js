﻿/*alert("Hello Innominds")*/
$(document).ready(function () {
var x = 0;
var s = "";
console.log("Hello Innomids")




/*var theform = document.getElementById("theform")*/
var theform = $("#theform")
theform.hide();
var button = $("#ViewDetails");
button.on("click", function () {
    alert("View the Data");
});

var Productinfo = $(".ProductProps li");
Productinfo.on("click", function () {

    console.log("you clicked on" + $(this).text());
});

    var $loginToggle = $("#$loginToggle")
    var $popupform = $(".popup-form");
    $loginToggle.on("click", function () {
        $popupform.slideToggle();
    });
   
});