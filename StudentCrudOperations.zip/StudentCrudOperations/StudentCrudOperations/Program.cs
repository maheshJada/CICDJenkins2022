﻿using System;


namespace StudentCrudOperations
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Choose the Operation \n1.Insert \n2.Update\n3.Delete\n4.Display");
            int n = int.Parse(Console.ReadLine());          //Here i read required operation what we want to do 
            studentmodel display = new studentmodel();            //I created the object for class i.e crudclass 

            switch (n)                                      // i use switch case if we select particular operation it will perform
            {
                case 1:
                    display.insert();
                    break;
                case 2:
                    display.update();
                    break;
                case 3:
                    display.delete();
                    break;
                case 4:
                    display.Select();
                   break;



            }
        }
    }
}
