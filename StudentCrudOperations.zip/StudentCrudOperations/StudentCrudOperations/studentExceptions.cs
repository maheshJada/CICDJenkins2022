﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace StudentCrudOperations
{
    class studentExceptions
    {
        internal class StudentCanNotBeNull : Exception
        {
            public StudentCanNotBeNull()
            {
            }

            public StudentCanNotBeNull(string message) : base(message)
            {
            }

            public StudentCanNotBeNull(string message, Exception innerException) : base(message, innerException)
            {
            }

            protected StudentCanNotBeNull(SerializationInfo info, StreamingContext context) : base(info, context)
            {
            }
        }
        internal class StudentClassValidationException : Exception
        {
            public StudentClassValidationException()
            {
            }

            public StudentClassValidationException(string message) : base(message)
            {
            }

            public StudentClassValidationException(string message, Exception innerException) : base(message, innerException)
            {
            }

            protected StudentClassValidationException(SerializationInfo info, StreamingContext context) : base(info, context)
            {
            }
        }
        internal class ClassException : Exception
        {
            public ClassException()
            {
            }

            public ClassException(string message) : base(message)
            {
            }

            public ClassException(string message, Exception innerException) : base(message, innerException)
            {
            }

            protected ClassException(SerializationInfo info, StreamingContext context) : base(info, context)
            {
            }
        }
    }
}
