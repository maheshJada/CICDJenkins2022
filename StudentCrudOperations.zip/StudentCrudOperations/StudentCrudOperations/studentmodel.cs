﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static StudentCrudOperations.studentExceptions;

namespace StudentCrudOperations
{
    class studentmodel
    {
        private static int Read(string message)             //Here i read the integer data 
        {
            Console.Write(message);
            try
            {
                return int.Parse(Console.ReadLine());
            }
            catch
            {
                return 0;
            }
        }
        // The information which is string that  is read if it satisfies otherwise it will throw an error 
        private static string Data(string message)          //Here i read the string data 
        {
            Console.Write(message);
            try
            {
                return Console.ReadLine();
            }
            catch
            {
                return " ";
            }
        }

        studentsqlstored store = new studentsqlstored();
        public string Name;
        public int Class;
        public void insert()
        {

            Console.WriteLine("Inserting data into Table:");
            StudentName:                                    //i used Exceptions
                try
                {
                    Name = Data("Enter Name:");
                    //it will chech if the name is not null and it will not be a number if it is enter it will throw an error
                    if (string.IsNullOrWhiteSpace(Name) == true)
                        throw new StudentCanNotBeNull("Student Name cannot be null:");
                    if (Name.Any(sn => char.IsLetter(sn) == false))
                        throw new StudentCanNotBeNull("Student  cannot be digits and symbols:");


                }
                catch (StudentCanNotBeNull e2)
                {
                    Console.WriteLine(e2.Message);
                    goto StudentName;
                }
            Student_Class:
                try
                {
                    Class = Read("Enter Class of the student : ");
                    if (Class > 15 || Class == 0)
                        //if  regNumber>100 or regNumber = 0 then it will throw an exception
                        throw new StudentClassValidationException("class must be less than 16:");



                }
                catch (StudentClassValidationException clsa)
                {
                    Console.WriteLine(clsa.Message);
                    goto Student_Class;
                }
                store.insert(Name, Class);
        }


        public void update()
        {
            Console.WriteLine("Upadating data from Table:");    
            StudentName:                        //i used Exceptions
                try
                {
                    Name = Data("Enter Name:");
                    //it will chech if the name is not null and it will not be a number if it is enter it will throw an error
                    if (string.IsNullOrWhiteSpace(Name) == true)
                        throw new StudentCanNotBeNull("Student Name cannot be null:");
                    if (Name.Any(sn => char.IsLetter(sn) == false))
                        throw new StudentCanNotBeNull("Student  cannot be digits and symbols:");


                }
                catch (StudentCanNotBeNull e2)
                {
                    Console.WriteLine(e2.Message);
                    goto StudentName;
                }
            Clss:
                try
                {
                    Class = Read("Enter class of the student : ");
                    if (Class > 15 || Class == 0)
                        //if  regNumber>100 or regNumber = 0 then it will throw an exception
                        throw new StudentClassValidationException("class must be less than 16:");



                }
                catch (StudentClassValidationException clsa)
                {
                    Console.WriteLine(clsa.Message);
                    goto Clss;
                }
                store.update(Name,Class);
            
        }

        public void delete()
        {
            Console.WriteLine("Deleting data from Record:");       
            StudentName:                                  
                try
                {
                    Name = Data("Enter Name:");
                    //it will chech if the name is not null and it will not be a number if it is enter it will throw an error
                    if (string.IsNullOrWhiteSpace(Name) == true)
                        throw new StudentCanNotBeNull("Student Name cannot be null:");
                    if (Name.Any(sn => char.IsLetter(sn) == false))
                        throw new StudentCanNotBeNull("Student  cannot be digits and symbols:");


                }
                catch (StudentCanNotBeNull e2)
                {
                    Console.WriteLine(e2.Message);
                    goto StudentName;
                }
            
            store.delete(Name);
        }
        public void Select()
        {
            store.Select();
        }
    }
}