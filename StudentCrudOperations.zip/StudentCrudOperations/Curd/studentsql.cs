﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace StudentCrudOperations
{
    public class studentsqlstored
    {
        private static string _connectionString = "server=IM-RT-LP-676\\SQLEXPRESS;database=mahesh1;integrated security=True;";
        SqlConnection cn;
        private string Class;

        public string Name;

        public void Select()
        {

            cn = new SqlConnection(_connectionString);
            Console.WriteLine("The Resultant of the Table data is:");
            Console.WriteLine("---------------------------------------------");

            using (SqlCommand _cmd = new SqlCommand("SELECT * FROM student", cn))
            {
                if (cn.State == System.Data.ConnectionState.Closed)
                    cn.Open();

                SqlDataReader dr = _cmd.ExecuteReader();

                while (dr.Read())
                {
                    //Here i display the database table records

                    Console.WriteLine("|RollNumber:   " + dr[0] + "  |Name:    " + dr[1] + "  |Class:     " + dr[2]);
                }
            }

        }

        public void insert(string Name, int Class)
        {
            try
            {
                cn = new SqlConnection(_connectionString);
                using (SqlCommand _cmd1 = new SqlCommand("insert into student values ('" + Name + "'," + Class + ")", cn))
                {
                    if (cn.State == System.Data.ConnectionState.Closed)
                        cn.Open();

                    _cmd1.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                cn.Close();
            }
            Select();
        }
        public void update(string Name, int Class)
        {
            try
            {
                cn = new SqlConnection(_connectionString);
                using (SqlCommand _cmd1 = new SqlCommand("update student set Class='" + Class + "' where Name='" + Name + "'", cn))
                {
                    if (cn.State == System.Data.ConnectionState.Closed)
                        cn.Open();

                    _cmd1.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                cn.Close();
            }
            
            Select();
        }


        public void delete(string Name)
        {
            try
            {
                cn = new SqlConnection(_connectionString);
                using (SqlCommand _cmd1 = new SqlCommand("delete from student  where Name='" + Name + "'", cn))
                {
                    if (cn.State == System.Data.ConnectionState.Closed)
                        cn.Open();

                    _cmd1.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                cn.Close();
            }
            Select();
        }

    }
}
