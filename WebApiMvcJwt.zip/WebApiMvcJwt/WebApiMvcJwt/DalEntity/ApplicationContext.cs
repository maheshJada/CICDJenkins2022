﻿
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using WebApiMvcJwt.DalEntity.Models;

namespace WebApiMvcJwt.DalEntity
{
    public class ApplicationContext :IdentityDbContext<ApplicationUser>
    {
     

        public ApplicationContext(DbContextOptions<ApplicationContext> options) : base(options)
        {

        }
       
        public DbSet<Category> CategoryTable1 { get; set; }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            //ModelBuilder.Seed();
        }
        //public DbSet<WebApiMvcJwt.DalEntity.Models.LoginModel> LoginModel { get; set; }
        //public DbSet<WebApiMvcJwt.DalEntity.Models.RegisterModel> RegisterModel { get; set; }
    }
}
