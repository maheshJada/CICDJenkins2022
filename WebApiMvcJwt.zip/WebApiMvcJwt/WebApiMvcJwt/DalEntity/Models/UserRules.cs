﻿namespace WebApiMvcJwt.DalEntity.Models
{
    public class UserRules
    {
        public const string Admin = "Admin";
        public const string User = "User";
    }
}
