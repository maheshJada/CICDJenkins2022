﻿using Microsoft.AspNetCore.Identity;

namespace WebApiMvcJwt.DalEntity.Models
{
    public class ApplicationUser: IdentityUser
    {
    }
}
