﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebApiMvcJwt.Migrations
{
    public partial class NewDb5 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
