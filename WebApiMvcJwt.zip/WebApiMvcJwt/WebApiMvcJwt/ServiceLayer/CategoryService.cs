﻿
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApiMvcJwt.DalEntity;
using WebApiMvcJwt.DalEntity.Models;
using Xunit;

namespace WebApiMvcJwt.ServiceLayer
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryService : ICategory
    {
        private readonly ApplicationContext _applicationContext;
        public CategoryService(ApplicationContext applicationContext)
        {
            _applicationContext = applicationContext;
        }
        [HttpDelete]
        public bool DeleteData(int id)
        {
            var data = _applicationContext.CategoryTable1.Find(id);
            _applicationContext.Remove(data);
            _applicationContext.SaveChanges();
            if (data != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
      
        [HttpGet, Route("GetData")]
        public IEnumerable<Category> GetData()
        {
            return _applicationContext.CategoryTable1;
        }
        [HttpGet, Route("ID")]
        public Category GetDataById(int id)
        {
            Category obj = _applicationContext.CategoryTable1.Find(id);
            if (obj != null)
                return obj;
            return obj;
        }
        [HttpPost]
        public bool InsertData(Category category)
        {
            var data = _applicationContext.CategoryTable1.Add(category);
            _applicationContext.SaveChanges();
            if (data != null)
                return true;
            else
                return false;
        }
        [HttpPut]
        public IEnumerable<Category> UpdateData(Category category)
        {
            _applicationContext.Update(category);
            _applicationContext.SaveChanges();
            return GetData();
        }
    }
}
