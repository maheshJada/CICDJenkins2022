﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApiMvcJwt.DalEntity.Models;

namespace WebApiMvcJwt.ServiceLayer
{
    public interface ICategory
    {
        IEnumerable<Category> GetData();

        bool InsertData(Category category);

        bool DeleteData(int id);

        IEnumerable<Category> UpdateData(Category category);

        Category GetDataById(int id);
    }
}
