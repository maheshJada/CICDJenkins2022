﻿#nullable disable
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using WebApiMvcJwt.DalEntity.Models;
using WebApiMvcJwt.ServiceLayer;

namespace RegLoginIdentity.Controllers
{
    public class LoginController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;

        public LoginController(UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager)
        {
            _signInManager = signInManager;
            _userManager = userManager;
        }
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Login([Bind("Email,Password")] LoginModel logModel)
        {
            if (ModelState.IsValid)
            {
                var result = await _signInManager.PasswordSignInAsync(logModel.Email, logModel.Password,false,false);
                if (result.Succeeded)
                {
                    return RedirectToAction("Index", "Category");
                }
                ModelState.AddModelError(string.Empty, "Invalid loginattempt");
            }
            return View(logModel);
        }
        //private readonly IUserServices _userServices;
        //public LoginController(IUserServices userServices)
        //{
        //    _userServices = userServices;
        //}
        //[HttpGet]
        //public IActionResult Login()
        //{
        //    return View();
        //}
        //[HttpPost]
        //public async Task<IActionResult> Login(LoginModel model)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        var result = await _signInManager.PasswordSignInAsync(logModel.Email, logModel.Password, logModel.Rememberme, false);
        //        if (result.Succeeded)
        //        {
        //            return RedirectToAction("Index", "Category");
        //        }


        //        ModelState.AddModelError(string.Empty, "Invalid loginattempt");

        //    }
        //    return View(model);
        //}
    }
}
