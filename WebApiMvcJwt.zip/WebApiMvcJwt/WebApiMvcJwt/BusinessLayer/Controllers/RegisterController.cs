﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using WebApiMvcJwt.DalEntity.Models;
using Microsoft.AspNetCore.Authorization;

namespace WebApiMvcJwt.BusinessLayer.Controllers
{
    public class RegisterController : Controller
    {
        private readonly UserManager<ApplicationUser> userManager;
        private readonly RoleManager<IdentityRole> roleManager;
        private readonly IConfiguration _configuration;
        private readonly SignInManager<ApplicationUser> _signInManager;
        public RegisterController(UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager, RoleManager<IdentityRole> roleManager, IConfiguration configuration)
        {
            this.userManager = userManager;
            this.roleManager = roleManager;
            _configuration = configuration;
            _signInManager = signInManager;
        }
        [HttpGet]
        [AllowAnonymous]
        public IActionResult Registerdata()
        {
            return View();
        }
        [HttpPost, ActionName("Registerdata")]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Registerdata(RegisterModel regModel)
        {
            if (ModelState.IsValid)
            {
                var user = new ApplicationUser { UserName = regModel.Email, Email = regModel.Email };
                var result = await userManager.CreateAsync(user, regModel.Password);
                if (result.Succeeded)
                {
                    await _signInManager.SignInAsync(user, isPersistent: false);
                    //return RedirectToAction("Login", "Login");
                    return RedirectToAction("Login", "Login");
                }
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                }
            }
            return View(regModel);
        }
    }
}
