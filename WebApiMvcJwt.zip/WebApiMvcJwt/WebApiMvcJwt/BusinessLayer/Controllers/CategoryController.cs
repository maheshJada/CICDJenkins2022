﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApiMvcJwt.BusinessLayer.CategoriesB;
using WebApiMvcJwt.DalEntity.Models;

namespace WebApiMvcJwt.BusinessLayer.Controllers
{
   // [Authorize]
    public class CategoryController : Controller
    {
        private readonly ICategoryBLS _categoryBLS;
        public CategoryController(ICategoryBLS categoryBLS)
        {
            _categoryBLS=categoryBLS;
        }
       
        [HttpGet]
        public ActionResult Index( )
        {
           var obj= _categoryBLS.GetData();
            return View(obj);
        }
        [HttpGet]
        public ActionResult Details(int id)
        {
            var data = _categoryBLS.GetDataById(id);
            return View(data);
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Category category)
        {
            if (_categoryBLS.InsertData(category))
            {
                return RedirectToAction("Index");
            }
            return View(category);
        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            var category = _categoryBLS.GetDataById(id);
            return View(category);
        }

        [HttpPost,ActionName("Edit")]
      
        public ActionResult Edit(int id, Category category)
        {
            if (ModelState.IsValid)
            {
                _categoryBLS.UpdateData(category);
            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Delete(int id)
        {
            var category = _categoryBLS.GetDataById(id);
            return View(category);
        }

        [HttpPost,ActionName("Delete")]
        public ActionResult DeleteConform(int id)
        {
            _categoryBLS.DeleteData(id);
            return RedirectToAction("Index");
        }
       
    }
}


