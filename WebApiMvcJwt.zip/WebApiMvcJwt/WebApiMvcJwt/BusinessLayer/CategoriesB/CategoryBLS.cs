﻿using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Mvc;
using WebApiMvcJwt.DalEntity.Models;
using WebApiMvcJwt.ServiceLayer;

namespace WebApiMvcJwt.BusinessLayer.CategoriesB
{

    public class CategoryBLS : ICategoryBLS
    {
        private readonly ICategory _categoryService;
        public CategoryBLS(ICategory categoryService)
        {
            _categoryService = categoryService;
        }

        public bool DeleteData(int id)
        {
            if (_categoryService.DeleteData(id))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public IEnumerable<Category> GetData()
        {
            return _categoryService.GetData();
        }

        public Category GetDataById(int id)
        {
            return _categoryService.GetDataById(id);
        }

        public bool InsertData(Category category)
        {
            if (_categoryService.InsertData(category))
                return true;
            return false;
        }

        public IEnumerable<Category> UpdateData(Category category)
        {
            return _categoryService.UpdateData(category);
        }
    }
}
