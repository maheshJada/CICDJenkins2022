﻿using WebApiMvcJwt.DalEntity.Models;

namespace WebApiMvcJwt.BusinessLayer.CategoriesB
{
    public interface ICategoryBLS
    {
        IEnumerable<Category> GetData();

        bool InsertData(Category category);

        bool DeleteData(int id);

        IEnumerable<Category> UpdateData(Category category);

        Category GetDataById(int id);
    }
}
