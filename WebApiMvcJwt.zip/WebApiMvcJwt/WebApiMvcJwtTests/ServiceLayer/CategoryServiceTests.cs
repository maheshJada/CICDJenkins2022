﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using WebApiMvcJwt.ServiceLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApiMvcJwt.ServiceLayer.Tests
{
    [TestClass()]
    public class CategoryServiceTests
    {
        [TestMethod()]
        public void GetDataTest()
        {
            Assert.Fail();
        }
    }
}